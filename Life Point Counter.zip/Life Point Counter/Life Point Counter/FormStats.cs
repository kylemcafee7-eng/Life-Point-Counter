﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Life_Point_Counter
{
    public partial class FormStats : Form
    {
        // Stats dictionaries
        private Dictionary<string, (int wins, int losses)> playerStats =
            new Dictionary<string, (int wins, int losses)>();

        private Dictionary<string, (int wins, int losses)> deckStats =
            new Dictionary<string, (int wins, int losses)>();

        public FormStats()
        {
            InitializeComponent();
            LoadStats();
        }

        private void listBoxStats_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        // loads and parses the stats file
        private void LoadStats()
        {
            playerStats.Clear();
            deckStats.Clear();

            string filePath = "stats.txt";
            if (!File.Exists(filePath))
            {
                listBoxStats.Items.Add("No stats file found.");
                return;
            }

            string[] lines = File.ReadAllLines(filePath);

            foreach (string line in lines)
            {
                if (line.StartsWith("Winners:", StringComparison.OrdinalIgnoreCase))
                {
                    string data = line.Substring("Winners:".Length).Trim();
                    if (string.IsNullOrWhiteSpace(data)) continue;

                    string[] entries = data.Split(',');

                    foreach (string entry in entries)
                    {
                        string trimmed = entry.Trim();
                        if (trimmed.Length == 0) continue;

                        int open = trimmed.IndexOf('(');
                        int close = trimmed.IndexOf(')');

                        if (open > 0 && close > open)
                        {
                            string name = trimmed.Substring(0, open).Trim().ToUpper();
                            string deck = trimmed.Substring(open + 1, close - open - 1).Trim().ToUpper();
                            AddWin(name, deck);
                        }
                    }
                }

                if (line.StartsWith("Losers:", StringComparison.OrdinalIgnoreCase))
                {
                    string data = line.Substring("Losers:".Length).Trim();
                    if (data.Equals("NONE", StringComparison.OrdinalIgnoreCase)) continue;

                    string[] entries = data.Split(',');

                    foreach (string entry in entries)
                    {
                        string trimmed = entry.Trim();
                        if (trimmed.Length == 0) continue;

                        int open = trimmed.IndexOf('(');
                        int close = trimmed.IndexOf(')');

                        if (open > 0 && close > open)
                        {
                            string name = trimmed.Substring(0, open).Trim().ToUpper();
                            string deck = trimmed.Substring(open + 1, close - open - 1).Trim().ToUpper();
                            AddLoss(name, deck);
                        }
                    }
                }
            }

            DisplayStats();
        }

        // Update stats 
        private void AddWin(string name, string deck)
        {   
            //checks for each repeating name in the file
            if (!playerStats.ContainsKey(name))
                playerStats[name] = (0, 0);

            // checks for each repeating deck name in the file 
            if (!deckStats.ContainsKey(deck))
                deckStats[deck] = (0, 0);

            // adds 1 to the win every time a player won with their deck, both the player and deck stats are incremented 
            var p = playerStats[name];
            playerStats[name] = (p.wins + 1, p.losses);

            var d = deckStats[deck];
            deckStats[deck] = (d.wins + 1, d.losses);
        }

        // same thing but for loses 
        private void AddLoss(string name, string deck)
        {
            if (!playerStats.ContainsKey(name))
                playerStats[name] = (0, 0);

            if (!deckStats.ContainsKey(deck))
                deckStats[deck] = (0, 0);

            var p = playerStats[name];
            playerStats[name] = (p.wins, p.losses + 1);

            var d = deckStats[deck];
            deckStats[deck] = (d.wins, d.losses + 1);
        }

         // displays the results in the list box, this is the only component in this form
        private void DisplayStats()
        {
            listBoxStats.Items.Clear();

            // generic header is printed 
            listBoxStats.Items.Add("Player Stats:");
            listBoxStats.Items.Add("-------------------------");

            // checks every key value pair in the playerstats dictionary
            foreach (var kvp in playerStats)
            {
                // retreives values from the dictionary and turns them into usable variables 
                string name = kvp.Key;
                int wins = kvp.Value.wins;
                int losses = kvp.Value.losses;
                int total = wins + losses;

                // calc win lost ratio as a percent 
                double ratio = total > 0 ? (double)wins / total * 100.0 : 0;

                // prints the list of values 
                listBoxStats.Items.Add($"{name}: {wins}W - {losses}L ({ratio:F2}%)");
            }

            // Generic header for deck, this functions exactly the same as the player
            listBoxStats.Items.Add("");
            listBoxStats.Items.Add("Deck Stats:");
            listBoxStats.Items.Add("-------------------------");

            foreach (var kvp in deckStats)
            {
                string deck = kvp.Key;
                int wins = kvp.Value.wins;
                int losses = kvp.Value.losses;
                int total = wins + losses;

                double ratio = total > 0 ? (double)wins / total * 100.0 : 0;

                listBoxStats.Items.Add($"{deck}: {wins}W - {losses}L ({ratio:F2}%)");
            }
        }
    }
}