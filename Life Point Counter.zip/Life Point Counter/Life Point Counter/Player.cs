﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Life_Point_Counter
{
    internal class Player
    {
        public string Name { get; set; }
        public string Deck { get; set; }
        public int LifePoints { get; set; }

        // This is used only during a match, not saved to file.
        public bool HasVictoryCondition { get; set; }

        public Player()
        {
            Name = "";
            Deck = "";
            LifePoints = 8000;
            HasVictoryCondition = false;
        }
    }
}
