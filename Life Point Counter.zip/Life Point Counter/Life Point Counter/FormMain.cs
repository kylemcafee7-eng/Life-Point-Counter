﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Life_Point_Counter
{
    public partial class FormMain : Form
    {
        // Six players for the match
        private List<Player> players = new List<Player>()
{
    new Player(),
    new Player(),
    new Player(),
    new Player(),
    new Player(),
    new Player()
};

        // Prepared action numeric value (LP changes)
        private int preparedNumericValue = 0;

        // Victory mode state
        private bool victoryActive = false;

        // Victory condition flags
        private bool[] victoryFlags = new bool[6];

        // Display text for prepared action (always a string)
        private string preparedDisplayText = "";

        public FormMain()
        {
            InitializeComponent();

            // Initialize LP textboxes to 8000
            textBoxPlayer1LP.Text = players[0].LifePoints.ToString();
            textBoxPlayer2LP.Text = players[1].LifePoints.ToString();
            textBoxPlayer3LP.Text = players[2].LifePoints.ToString();
            textBoxPlayer4LP.Text = players[3].LifePoints.ToString();
            textBoxPlayer5LP.Text = players[4].LifePoints.ToString();
            textBoxPlayer6LP.Text = players[5].LifePoints.ToString();

        }



        private void ResetFormState()
        {
            // Clear player names and decks
            textBoxPlayer1.Text = "";
            textBoxPlayer2.Text = "";
            textBoxPlayer3.Text = "";
            textBoxPlayer4.Text = "";
            textBoxPlayer5.Text = "";
            textBoxPlayer6.Text = "";

            textBoxPlayer1Deck.Text = "";
            textBoxPlayer2Deck.Text = "";
            textBoxPlayer3Deck.Text = "";
            textBoxPlayer4Deck.Text = "";
            textBoxPlayer5Deck.Text = "";
            textBoxPlayer6Deck.Text = "";

            // Reset LP values
            players[0].LifePoints = 8000;
            players[1].LifePoints = 8000;
            players[2].LifePoints = 8000;
            players[3].LifePoints = 8000;
            players[4].LifePoints = 8000;
            players[5].LifePoints = 8000;

            textBoxPlayer1LP.Text = "8000";
            textBoxPlayer2LP.Text = "8000";
            textBoxPlayer3LP.Text = "8000";
            textBoxPlayer4LP.Text = "8000";
            textBoxPlayer5LP.Text = "8000";
            textBoxPlayer6LP.Text = "8000";

            // Clear prepared action
            preparedNumericValue = 0;
            preparedDisplayText = "";
            textBoxPreparedAction.Text = "";
            textBoxCustomValue.Text = "";

            // Clear last action
            textBoxLastAction.Text = "";

            // Clear victory flags
            for (int i = 0; i < 6; i++)
                victoryFlags[i] = false;

            // Turn off victory mode
            victoryActive = false;
        }

        private void ResolveVictory()
        {
            // Determine active players (those with both name and deck)
            List<int> activePlayers = new List<int>();
            for (int i = 0; i < 6; i++)
            {
                if (!string.IsNullOrWhiteSpace(players[i].Name) &&
                    !string.IsNullOrWhiteSpace(players[i].Deck))
                {
                    activePlayers.Add(i);
                }
            }

            // Need at least 1 active player to resolve victory
            if (activePlayers.Count < 1)
            {
                MessageBox.Show("At least one player must have a name and deck to resolve victory.");
                return;
            }

            // Collect winners (any player with a victory flag and valid name/deck)
            List<int> winnerIndexes = new List<int>();
            for (int i = 0; i < 6; i++)
            {
                if (victoryFlags[i] &&
                    !string.IsNullOrWhiteSpace(players[i].Name) &&
                    !string.IsNullOrWhiteSpace(players[i].Deck))
                {
                    winnerIndexes.Add(i);
                }
            }

            // Must have at least one winner
            if (winnerIndexes.Count == 0)
            {
                MessageBox.Show("At least one winning player must be selected.");
                return;
            }

            // Build winners and losers lists (trim + uppercase)
            List<string> winners = new List<string>();
            List<string> losers = new List<string>();

            foreach (int i in winnerIndexes)
            {
                string name = players[i].Name.Trim().ToUpper();
                string deck = players[i].Deck.Trim().ToUpper();
                winners.Add($"{name} ({deck})");
            }

            foreach (int i in activePlayers)
            {
                if (!winnerIndexes.Contains(i))
                {
                    string name = players[i].Name.Trim().ToUpper();
                    string deck = players[i].Deck.Trim().ToUpper();
                    losers.Add($"{name} ({deck})");
                }
            }

            // Write to stats file
            string filePath = "stats.txt";
            using (StreamWriter sw = new StreamWriter(filePath, true))
            {
                sw.WriteLine("Match Result:");
                sw.WriteLine("Winners: " + string.Join(", ", winners));

                if (losers.Count > 0)
                    sw.WriteLine("Losers: " + string.Join(", ", losers));
                else
                    sw.WriteLine("Losers: NONE");

                sw.WriteLine("Date: " + DateTime.Now.ToString());
                sw.WriteLine("----------------------------------------");
            }

            // Log in action history
            string resultText = "Victory resolved. Winners: " + string.Join(", ", winners);
            listBoxActionHistory.Items.Add(resultText);
            textBoxLastAction.Text = resultText;

            // Show winners in a message box
            MessageBox.Show("Winners: " + string.Join(", ", winners));

            // ResetFormState();  
        }

        private void ToggleVictoryForPlayer(int index)
        {
            // Flip the flag
            victoryFlags[index] = !victoryFlags[index];

            // Update last action
            if (victoryFlags[index])
                textBoxLastAction.Text = $"{players[index].Name} has been given the victory condition.";
            else
                textBoxLastAction.Text = $"{players[index].Name} no longer has the victory condition.";

            // Add to history
            listBoxActionHistory.Items.Add(textBoxLastAction.Text);

            // Update display
            UpdateVictoryDisplay();
        }

        private void UpdateVictoryDisplay()
        {
            if (!victoryActive)
            {
                preparedDisplayText = "";
                textBoxPreparedAction.Text = "";
                return;
            }

            // Build list of players with victory condition
            List<string> winners = new List<string>();

            for (int i = 0; i < 6; i++)
            {
                if (victoryFlags[i])
                    winners.Add(players[i].Name);
            }

            if (winners.Count == 0)
            {
                preparedDisplayText = "Victory is Active. Current Winners: ";
            }
            else
            {
                preparedDisplayText = "Victory is Active. Current Winners: " + string.Join(", ", winners);
            }

            textBoxPreparedAction.Text = preparedDisplayText;
        }

        private void ApplyNumericToPlayer(int index)
        {
            // If prepared action is not numeric, do nothing here (victory mode will handle later)
            if (!preparedDisplayText.StartsWith("Prepared:"))
                return;

            // Apply LP change
            players[index].LifePoints += preparedNumericValue;

            // Clamp LP to minimum 0 (optional but common)
            if (players[index].LifePoints < 0)
                players[index].LifePoints = 0;

            // Update LP textbox
            switch (index)
            {
                case 0: textBoxPlayer1LP.Text = players[0].LifePoints.ToString(); break;
                case 1: textBoxPlayer2LP.Text = players[1].LifePoints.ToString(); break;
                case 2: textBoxPlayer3LP.Text = players[2].LifePoints.ToString(); break;
                case 3: textBoxPlayer4LP.Text = players[3].LifePoints.ToString(); break;
                case 4: textBoxPlayer5LP.Text = players[4].LifePoints.ToString(); break;
                case 5: textBoxPlayer6LP.Text = players[5].LifePoints.ToString(); break;
            }

            // Update last action
            textBoxLastAction.Text = $"{players[index].Name} LP changed by {preparedNumericValue}";

            // Add to action history
            listBoxActionHistory.Items.Add(textBoxLastAction.Text);

            // Clear numeric prepared action
            preparedNumericValue = 0;
            preparedDisplayText = "";
            textBoxPreparedAction.Text = "";

            // Clear custom value box
            textBoxCustomValue.Text = "";
        }
        private void ClearNumericPreparedAction()
        {
            preparedNumericValue = 0;

            // Only clear display if it was numeric
            if (preparedDisplayText.StartsWith("Prepared:"))
            {
                preparedDisplayText = "";
                textBoxPreparedAction.Text = "";
            }
        }

        private void UpdatePreparedActionDisplay()
        {
            // If numeric value is non-zero, show "Prepared: X"
            if (preparedNumericValue != 0)
            {
                preparedDisplayText = "Prepared: " + preparedNumericValue;
                textBoxPreparedAction.Text = preparedDisplayText;
                return;
            }

            // If numeric value is zero but display text is numeric, clear it
            if (preparedDisplayText.StartsWith("Prepared:"))
            {
                preparedDisplayText = "";
                textBoxPreparedAction.Text = "";
                return;
            }

            // Otherwise, display whatever text is stored (victory mode, error, etc.)
            textBoxPreparedAction.Text = preparedDisplayText;
        }

        private void textBoxPlayer1_TextChanged(object sender, EventArgs e)
        {
            players[0].Name = textBoxPlayer1.Text;

        }

        private void textBoxPlayer1Deck_TextChanged(object sender, EventArgs e)
        {
            players[0].Deck = textBoxPlayer1Deck.Text;

        }

        private void textBoxPlayer1LP_TextChanged(object sender, EventArgs e)
        {
        
        }

        private void buttonPlayer1_Click(object sender, EventArgs e)
        {
            if (victoryActive)
            {
                ToggleVictoryForPlayer(0);
                return;
            }

            ApplyNumericToPlayer(0);

        }

        private void textBoxPlayer2_TextChanged(object sender, EventArgs e)
        {
            players[1].Name = textBoxPlayer2.Text;

        }

        private void textBoxPlayer2Deck_TextChanged(object sender, EventArgs e)
        {
            players[1].Deck = textBoxPlayer2Deck.Text;

        }

        private void textBoxPlayer2LP_TextChanged(object sender, EventArgs e)
        {
   

        }

        private void buttonPlayer2_Click(object sender, EventArgs e)
        {
            if (victoryActive)
            {
                ToggleVictoryForPlayer(1);
                return;
            }

            ApplyNumericToPlayer(1);

        }

        private void textBoxPlayer3_TextChanged(object sender, EventArgs e)
        {
            players[2].Name = textBoxPlayer3.Text;

        }

        private void textBoxPlayer3Deck_TextChanged(object sender, EventArgs e)
        {
            players[2].Deck = textBoxPlayer3Deck.Text;

        }

        private void textBoxPlayer3LP_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonPlayer3_Click(object sender, EventArgs e)
        {
            if (victoryActive)
            {
                ToggleVictoryForPlayer(2);
                return;
            }

            ApplyNumericToPlayer(2);

        }

        private void textBoxPlayer4_TextChanged(object sender, EventArgs e)
        {
            players[3].Name = textBoxPlayer4.Text;

        }

        private void textBoxPlayer4Deck_TextChanged(object sender, EventArgs e)
        {
            players[3].Deck = textBoxPlayer4Deck.Text;

        }

        private void textBoxPlayer4LP_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonPlayer4_Click(object sender, EventArgs e)
        {
            if (victoryActive)
            {
                ToggleVictoryForPlayer(3);
                return;
            }

            ApplyNumericToPlayer(3);

        }

        private void textBoxPlayer5_TextChanged(object sender, EventArgs e)
        {
            players[4].Name = textBoxPlayer5.Text;
        }

        private void textBoxPlayer5Deck_TextChanged(object sender, EventArgs e)
        {
            players[4].Deck = textBoxPlayer5Deck.Text;

        }

        private void textBoxPlayer5LP_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void buttonPlayer5_Click(object sender, EventArgs e)
        {
            if (victoryActive)
            {
                ToggleVictoryForPlayer(4);
                return;
            }

            ApplyNumericToPlayer(4);

        }

        private void textBoxPlayer6_TextChanged(object sender, EventArgs e)
        {
            players[5].Name = textBoxPlayer6.Text;

        }

        private void textBoxPlayer6Deck_TextChanged(object sender, EventArgs e)
        {
            players[5].Deck = textBoxPlayer6Deck.Text;

        }

        private void textBoxPlayer6LP_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonPlayer6_Click(object sender, EventArgs e)
        {
            if (victoryActive)
            {
                ToggleVictoryForPlayer(5);
                return;
            }

            ApplyNumericToPlayer(5);
        }

        private void textBoxPreparedAction_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxLastAction_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonCoin_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            string result = r.Next(0, 2) == 0 ? "Heads" : "Tails";

            string msg = "Coin Flip: " + result;

            textBoxLastAction.Text = msg;
            listBoxActionHistory.Items.Add(msg);

            // Clear prepared action
            preparedNumericValue = 0;
            preparedDisplayText = "";
            textBoxPreparedAction.Text = "";

        }

        private void buttonD6_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            int result = r.Next(1, 7);

            string msg = "1d6 Roll: " + result;

            textBoxLastAction.Text = msg;
            listBoxActionHistory.Items.Add(msg);

            // Clear prepared action
            preparedNumericValue = 0;
            preparedDisplayText = "";
            textBoxPreparedAction.Text = "";

        }

        private void buttonD20_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            int result = r.Next(1, 21);

            string msg = "1d20 Roll: " + result;

            textBoxLastAction.Text = msg;
            listBoxActionHistory.Items.Add(msg);

            // Clear prepared action
            preparedNumericValue = 0;
            preparedDisplayText = "";
            textBoxPreparedAction.Text = "";

        }

        private void button50_Click(object sender, EventArgs e)
        {
            if (!preparedDisplayText.StartsWith("Prepared:"))
                preparedNumericValue = 0;

            preparedNumericValue += 50;
            UpdatePreparedActionDisplay();

        }

        private void buttonMinus50_Click(object sender, EventArgs e)
        {
            if (!preparedDisplayText.StartsWith("Prepared:"))
                preparedNumericValue = 0;

            preparedNumericValue -= 50;
            UpdatePreparedActionDisplay();

        }

        private void button100_Click(object sender, EventArgs e)
        {
            if (!preparedDisplayText.StartsWith("Prepared:"))
                preparedNumericValue = 0;

            preparedNumericValue += 100;
            UpdatePreparedActionDisplay();

        }

        private void buttonMinus100_Click(object sender, EventArgs e)
        {
            if (!preparedDisplayText.StartsWith("Prepared:"))
                preparedNumericValue = 0;

            preparedNumericValue -= 100;
            UpdatePreparedActionDisplay();

        }

        private void button500_Click(object sender, EventArgs e)
        {
            if (!preparedDisplayText.StartsWith("Prepared:"))
                preparedNumericValue = 0;

            preparedNumericValue += 500;
            UpdatePreparedActionDisplay();

        }

        private void buttonMinus500_Click(object sender, EventArgs e)
        {
            if (!preparedDisplayText.StartsWith("Prepared:"))
                preparedNumericValue = 0;

            preparedNumericValue -= 500;
            UpdatePreparedActionDisplay();

        }

        private void button1000_Click(object sender, EventArgs e)
        {
            if (!preparedDisplayText.StartsWith("Prepared:"))
                preparedNumericValue = 0;

            preparedNumericValue += 1000;
            UpdatePreparedActionDisplay();

        }

        private void buttonMinus1000_Click(object sender, EventArgs e)
        {
            if (!preparedDisplayText.StartsWith("Prepared:"))
                preparedNumericValue = 0;

            preparedNumericValue -= 1000;
            UpdatePreparedActionDisplay();

        }

        private void textBoxCustomValue_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxCustomValue.Text))
                return;

            int value;
            if (!int.TryParse(textBoxCustomValue.Text, out value))
            {
                preparedNumericValue = 0;
                preparedDisplayText = "Error: please only entry numbers as a custom value.";
                textBoxPreparedAction.Text = preparedDisplayText;
                return;
            }

            // If previous prepared action wasn't numeric, reset
            if (!preparedDisplayText.StartsWith("Prepared:"))
                preparedNumericValue = 0;

            preparedNumericValue += value;
            preparedDisplayText = "Prepared: " + preparedNumericValue;
            textBoxPreparedAction.Text = preparedDisplayText;

        }

        private void listBoxActionHistory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void buttonVictory_Click(object sender, EventArgs e)
        {
            if (!victoryActive)
            {
                victoryActive = true;

                preparedNumericValue = 0;

                for (int i = 0; i < 6; i++)
                    victoryFlags[i] = false;

                UpdateVictoryDisplay();
                return;
            }

            bool anyWinners = victoryFlags.Any(v => v);

            if (!anyWinners)
            {
                victoryActive = false;
                preparedNumericValue = 0;
                preparedDisplayText = "";
                textBoxPreparedAction.Text = "";
                return;
            }

            // If victory is active AND winners exist → resolve victory
            ResolveVictory();

        }

        private void buttonStats_Click(object sender, EventArgs e)
        {
            FormStats statsForm = new FormStats();
            statsForm.Show();

        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            ResetFormState();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void labelPlayer1_Click(object sender, EventArgs e)
        {

        }

        //update button
        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
