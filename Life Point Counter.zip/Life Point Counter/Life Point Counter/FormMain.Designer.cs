﻿namespace Life_Point_Counter
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxPlayer1 = new System.Windows.Forms.GroupBox();
            this.textBoxPlayer1LP = new System.Windows.Forms.TextBox();
            this.textBoxPlayer1Deck = new System.Windows.Forms.TextBox();
            this.textBoxPlayer1 = new System.Windows.Forms.TextBox();
            this.buttonPlayer1 = new System.Windows.Forms.Button();
            this.labelPlayer1LP = new System.Windows.Forms.Label();
            this.labelPlayer1Deck = new System.Windows.Forms.Label();
            this.labelPlayer1 = new System.Windows.Forms.Label();
            this.groupBoxPlayer2 = new System.Windows.Forms.GroupBox();
            this.textBoxPlayer2LP = new System.Windows.Forms.TextBox();
            this.textBoxPlayer2Deck = new System.Windows.Forms.TextBox();
            this.textBoxPlayer2 = new System.Windows.Forms.TextBox();
            this.buttonPlayer2 = new System.Windows.Forms.Button();
            this.labelPlayer2LP = new System.Windows.Forms.Label();
            this.labelPlayer2Deck = new System.Windows.Forms.Label();
            this.labelPlayer2 = new System.Windows.Forms.Label();
            this.groupBoxPlayer3 = new System.Windows.Forms.GroupBox();
            this.textBoxPlayer3LP = new System.Windows.Forms.TextBox();
            this.textBoxPlayer3Deck = new System.Windows.Forms.TextBox();
            this.textBoxPlayer3 = new System.Windows.Forms.TextBox();
            this.buttonPlayer3 = new System.Windows.Forms.Button();
            this.labelPlayer3LP = new System.Windows.Forms.Label();
            this.labelPlayer3Deck = new System.Windows.Forms.Label();
            this.labelPlayer3 = new System.Windows.Forms.Label();
            this.groupBoxPlayer4 = new System.Windows.Forms.GroupBox();
            this.textBoxPlayer4LP = new System.Windows.Forms.TextBox();
            this.textBoxPlayer4Deck = new System.Windows.Forms.TextBox();
            this.textBoxPlayer4 = new System.Windows.Forms.TextBox();
            this.buttonPlayer4 = new System.Windows.Forms.Button();
            this.labelPlayer4LP = new System.Windows.Forms.Label();
            this.labelPlayer4Deck = new System.Windows.Forms.Label();
            this.labelPlayer4 = new System.Windows.Forms.Label();
            this.groupBoxPlayer5 = new System.Windows.Forms.GroupBox();
            this.textBoxPlayer5LP = new System.Windows.Forms.TextBox();
            this.textBoxPlayer5Deck = new System.Windows.Forms.TextBox();
            this.textBoxPlayer5 = new System.Windows.Forms.TextBox();
            this.buttonPlayer5 = new System.Windows.Forms.Button();
            this.labelPlayer5LP = new System.Windows.Forms.Label();
            this.labelPlayer5Deck = new System.Windows.Forms.Label();
            this.labelPlayer5 = new System.Windows.Forms.Label();
            this.groupBoxPlayer6 = new System.Windows.Forms.GroupBox();
            this.textBoxPlayer6LP = new System.Windows.Forms.TextBox();
            this.textBoxPlayer6Deck = new System.Windows.Forms.TextBox();
            this.textBoxPlayer6 = new System.Windows.Forms.TextBox();
            this.buttonPlayer6 = new System.Windows.Forms.Button();
            this.labelPlayer6LP = new System.Windows.Forms.Label();
            this.labelPlayer6Deck = new System.Windows.Forms.Label();
            this.labelPlayer6 = new System.Windows.Forms.Label();
            this.buttonCoin = new System.Windows.Forms.Button();
            this.buttonD6 = new System.Windows.Forms.Button();
            this.buttonD20 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.buttonMinus50 = new System.Windows.Forms.Button();
            this.button100 = new System.Windows.Forms.Button();
            this.buttonMinus100 = new System.Windows.Forms.Button();
            this.button500 = new System.Windows.Forms.Button();
            this.buttonMinus500 = new System.Windows.Forms.Button();
            this.button1000 = new System.Windows.Forms.Button();
            this.buttonMinus1000 = new System.Windows.Forms.Button();
            this.labelCustomValue = new System.Windows.Forms.Label();
            this.textBoxCustomValue = new System.Windows.Forms.TextBox();
            this.labelDice = new System.Windows.Forms.Label();
            this.labelQuickValues = new System.Windows.Forms.Label();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonReset = new System.Windows.Forms.Button();
            this.buttonStats = new System.Windows.Forms.Button();
            this.buttonVictory = new System.Windows.Forms.Button();
            this.labelPreparedAction = new System.Windows.Forms.Label();
            this.labelLastAction = new System.Windows.Forms.Label();
            this.listBoxActionHistory = new System.Windows.Forms.ListBox();
            this.textBoxPreparedAction = new System.Windows.Forms.TextBox();
            this.textBoxLastAction = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBoxPlayer1.SuspendLayout();
            this.groupBoxPlayer2.SuspendLayout();
            this.groupBoxPlayer3.SuspendLayout();
            this.groupBoxPlayer4.SuspendLayout();
            this.groupBoxPlayer5.SuspendLayout();
            this.groupBoxPlayer6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxPlayer1
            // 
            this.groupBoxPlayer1.Controls.Add(this.textBoxPlayer1LP);
            this.groupBoxPlayer1.Controls.Add(this.textBoxPlayer1Deck);
            this.groupBoxPlayer1.Controls.Add(this.textBoxPlayer1);
            this.groupBoxPlayer1.Controls.Add(this.buttonPlayer1);
            this.groupBoxPlayer1.Controls.Add(this.labelPlayer1LP);
            this.groupBoxPlayer1.Controls.Add(this.labelPlayer1Deck);
            this.groupBoxPlayer1.Controls.Add(this.labelPlayer1);
            this.groupBoxPlayer1.Location = new System.Drawing.Point(12, 12);
            this.groupBoxPlayer1.Name = "groupBoxPlayer1";
            this.groupBoxPlayer1.Size = new System.Drawing.Size(268, 110);
            this.groupBoxPlayer1.TabIndex = 0;
            this.groupBoxPlayer1.TabStop = false;
            this.groupBoxPlayer1.Text = "Player 1";
            // 
            // textBoxPlayer1LP
            // 
            this.textBoxPlayer1LP.Enabled = false;
            this.textBoxPlayer1LP.Location = new System.Drawing.Point(56, 69);
            this.textBoxPlayer1LP.Name = "textBoxPlayer1LP";
            this.textBoxPlayer1LP.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer1LP.TabIndex = 9;
            this.textBoxPlayer1LP.Text = "8000";
            this.textBoxPlayer1LP.TextChanged += new System.EventHandler(this.textBoxPlayer1LP_TextChanged);
            // 
            // textBoxPlayer1Deck
            // 
            this.textBoxPlayer1Deck.Location = new System.Drawing.Point(56, 43);
            this.textBoxPlayer1Deck.Name = "textBoxPlayer1Deck";
            this.textBoxPlayer1Deck.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer1Deck.TabIndex = 8;
            this.textBoxPlayer1Deck.TextChanged += new System.EventHandler(this.textBoxPlayer1Deck_TextChanged);
            // 
            // textBoxPlayer1
            // 
            this.textBoxPlayer1.Location = new System.Drawing.Point(56, 16);
            this.textBoxPlayer1.Name = "textBoxPlayer1";
            this.textBoxPlayer1.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer1.TabIndex = 7;
            this.textBoxPlayer1.TextChanged += new System.EventHandler(this.textBoxPlayer1_TextChanged);
            // 
            // buttonPlayer1
            // 
            this.buttonPlayer1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonPlayer1.Location = new System.Drawing.Point(162, 29);
            this.buttonPlayer1.Name = "buttonPlayer1";
            this.buttonPlayer1.Size = new System.Drawing.Size(97, 47);
            this.buttonPlayer1.TabIndex = 6;
            this.buttonPlayer1.Text = "Apply";
            this.buttonPlayer1.UseVisualStyleBackColor = false;
            this.buttonPlayer1.Click += new System.EventHandler(this.buttonPlayer1_Click);
            // 
            // labelPlayer1LP
            // 
            this.labelPlayer1LP.AutoSize = true;
            this.labelPlayer1LP.Location = new System.Drawing.Point(6, 69);
            this.labelPlayer1LP.Name = "labelPlayer1LP";
            this.labelPlayer1LP.Size = new System.Drawing.Size(23, 13);
            this.labelPlayer1LP.TabIndex = 2;
            this.labelPlayer1LP.Text = "LP:";
            // 
            // labelPlayer1Deck
            // 
            this.labelPlayer1Deck.AutoSize = true;
            this.labelPlayer1Deck.Location = new System.Drawing.Point(6, 43);
            this.labelPlayer1Deck.Name = "labelPlayer1Deck";
            this.labelPlayer1Deck.Size = new System.Drawing.Size(36, 13);
            this.labelPlayer1Deck.TabIndex = 1;
            this.labelPlayer1Deck.Text = "Deck:";
            // 
            // labelPlayer1
            // 
            this.labelPlayer1.AutoSize = true;
            this.labelPlayer1.Location = new System.Drawing.Point(6, 16);
            this.labelPlayer1.Name = "labelPlayer1";
            this.labelPlayer1.Size = new System.Drawing.Size(39, 13);
            this.labelPlayer1.TabIndex = 0;
            this.labelPlayer1.Text = "Player:";
            this.labelPlayer1.Click += new System.EventHandler(this.labelPlayer1_Click);
            // 
            // groupBoxPlayer2
            // 
            this.groupBoxPlayer2.Controls.Add(this.textBoxPlayer2LP);
            this.groupBoxPlayer2.Controls.Add(this.textBoxPlayer2Deck);
            this.groupBoxPlayer2.Controls.Add(this.textBoxPlayer2);
            this.groupBoxPlayer2.Controls.Add(this.buttonPlayer2);
            this.groupBoxPlayer2.Controls.Add(this.labelPlayer2LP);
            this.groupBoxPlayer2.Controls.Add(this.labelPlayer2Deck);
            this.groupBoxPlayer2.Controls.Add(this.labelPlayer2);
            this.groupBoxPlayer2.Location = new System.Drawing.Point(12, 128);
            this.groupBoxPlayer2.Name = "groupBoxPlayer2";
            this.groupBoxPlayer2.Size = new System.Drawing.Size(268, 110);
            this.groupBoxPlayer2.TabIndex = 10;
            this.groupBoxPlayer2.TabStop = false;
            this.groupBoxPlayer2.Text = "Player 2";
            // 
            // textBoxPlayer2LP
            // 
            this.textBoxPlayer2LP.Enabled = false;
            this.textBoxPlayer2LP.Location = new System.Drawing.Point(56, 69);
            this.textBoxPlayer2LP.Name = "textBoxPlayer2LP";
            this.textBoxPlayer2LP.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer2LP.TabIndex = 9;
            this.textBoxPlayer2LP.Text = "8000";
            this.textBoxPlayer2LP.TextChanged += new System.EventHandler(this.textBoxPlayer2LP_TextChanged);
            // 
            // textBoxPlayer2Deck
            // 
            this.textBoxPlayer2Deck.Location = new System.Drawing.Point(56, 43);
            this.textBoxPlayer2Deck.Name = "textBoxPlayer2Deck";
            this.textBoxPlayer2Deck.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer2Deck.TabIndex = 8;
            this.textBoxPlayer2Deck.TextChanged += new System.EventHandler(this.textBoxPlayer2Deck_TextChanged);
            // 
            // textBoxPlayer2
            // 
            this.textBoxPlayer2.Location = new System.Drawing.Point(56, 16);
            this.textBoxPlayer2.Name = "textBoxPlayer2";
            this.textBoxPlayer2.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer2.TabIndex = 7;
            this.textBoxPlayer2.TextChanged += new System.EventHandler(this.textBoxPlayer2_TextChanged);
            // 
            // buttonPlayer2
            // 
            this.buttonPlayer2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonPlayer2.Location = new System.Drawing.Point(162, 29);
            this.buttonPlayer2.Name = "buttonPlayer2";
            this.buttonPlayer2.Size = new System.Drawing.Size(97, 47);
            this.buttonPlayer2.TabIndex = 6;
            this.buttonPlayer2.Text = "Apply";
            this.buttonPlayer2.UseVisualStyleBackColor = false;
            this.buttonPlayer2.Click += new System.EventHandler(this.buttonPlayer2_Click);
            // 
            // labelPlayer2LP
            // 
            this.labelPlayer2LP.AutoSize = true;
            this.labelPlayer2LP.Location = new System.Drawing.Point(6, 69);
            this.labelPlayer2LP.Name = "labelPlayer2LP";
            this.labelPlayer2LP.Size = new System.Drawing.Size(23, 13);
            this.labelPlayer2LP.TabIndex = 2;
            this.labelPlayer2LP.Text = "LP:";
            // 
            // labelPlayer2Deck
            // 
            this.labelPlayer2Deck.AutoSize = true;
            this.labelPlayer2Deck.Location = new System.Drawing.Point(6, 43);
            this.labelPlayer2Deck.Name = "labelPlayer2Deck";
            this.labelPlayer2Deck.Size = new System.Drawing.Size(36, 13);
            this.labelPlayer2Deck.TabIndex = 1;
            this.labelPlayer2Deck.Text = "Deck:";
            // 
            // labelPlayer2
            // 
            this.labelPlayer2.AutoSize = true;
            this.labelPlayer2.Location = new System.Drawing.Point(6, 16);
            this.labelPlayer2.Name = "labelPlayer2";
            this.labelPlayer2.Size = new System.Drawing.Size(39, 13);
            this.labelPlayer2.TabIndex = 0;
            this.labelPlayer2.Text = "Player:";
            // 
            // groupBoxPlayer3
            // 
            this.groupBoxPlayer3.Controls.Add(this.textBoxPlayer3LP);
            this.groupBoxPlayer3.Controls.Add(this.textBoxPlayer3Deck);
            this.groupBoxPlayer3.Controls.Add(this.textBoxPlayer3);
            this.groupBoxPlayer3.Controls.Add(this.buttonPlayer3);
            this.groupBoxPlayer3.Controls.Add(this.labelPlayer3LP);
            this.groupBoxPlayer3.Controls.Add(this.labelPlayer3Deck);
            this.groupBoxPlayer3.Controls.Add(this.labelPlayer3);
            this.groupBoxPlayer3.Location = new System.Drawing.Point(12, 244);
            this.groupBoxPlayer3.Name = "groupBoxPlayer3";
            this.groupBoxPlayer3.Size = new System.Drawing.Size(268, 110);
            this.groupBoxPlayer3.TabIndex = 10;
            this.groupBoxPlayer3.TabStop = false;
            this.groupBoxPlayer3.Text = "Player 3";
            // 
            // textBoxPlayer3LP
            // 
            this.textBoxPlayer3LP.Enabled = false;
            this.textBoxPlayer3LP.Location = new System.Drawing.Point(56, 69);
            this.textBoxPlayer3LP.Name = "textBoxPlayer3LP";
            this.textBoxPlayer3LP.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer3LP.TabIndex = 9;
            this.textBoxPlayer3LP.Text = "8000";
            this.textBoxPlayer3LP.TextChanged += new System.EventHandler(this.textBoxPlayer3LP_TextChanged);
            // 
            // textBoxPlayer3Deck
            // 
            this.textBoxPlayer3Deck.Location = new System.Drawing.Point(56, 43);
            this.textBoxPlayer3Deck.Name = "textBoxPlayer3Deck";
            this.textBoxPlayer3Deck.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer3Deck.TabIndex = 8;
            this.textBoxPlayer3Deck.TextChanged += new System.EventHandler(this.textBoxPlayer3Deck_TextChanged);
            // 
            // textBoxPlayer3
            // 
            this.textBoxPlayer3.Location = new System.Drawing.Point(56, 16);
            this.textBoxPlayer3.Name = "textBoxPlayer3";
            this.textBoxPlayer3.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer3.TabIndex = 7;
            this.textBoxPlayer3.TextChanged += new System.EventHandler(this.textBoxPlayer3_TextChanged);
            // 
            // buttonPlayer3
            // 
            this.buttonPlayer3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonPlayer3.Location = new System.Drawing.Point(162, 29);
            this.buttonPlayer3.Name = "buttonPlayer3";
            this.buttonPlayer3.Size = new System.Drawing.Size(97, 47);
            this.buttonPlayer3.TabIndex = 6;
            this.buttonPlayer3.Text = "Apply";
            this.buttonPlayer3.UseVisualStyleBackColor = false;
            this.buttonPlayer3.Click += new System.EventHandler(this.buttonPlayer3_Click);
            // 
            // labelPlayer3LP
            // 
            this.labelPlayer3LP.AutoSize = true;
            this.labelPlayer3LP.Location = new System.Drawing.Point(6, 69);
            this.labelPlayer3LP.Name = "labelPlayer3LP";
            this.labelPlayer3LP.Size = new System.Drawing.Size(23, 13);
            this.labelPlayer3LP.TabIndex = 2;
            this.labelPlayer3LP.Text = "LP:";
            // 
            // labelPlayer3Deck
            // 
            this.labelPlayer3Deck.AutoSize = true;
            this.labelPlayer3Deck.Location = new System.Drawing.Point(6, 43);
            this.labelPlayer3Deck.Name = "labelPlayer3Deck";
            this.labelPlayer3Deck.Size = new System.Drawing.Size(36, 13);
            this.labelPlayer3Deck.TabIndex = 1;
            this.labelPlayer3Deck.Text = "Deck:";
            // 
            // labelPlayer3
            // 
            this.labelPlayer3.AutoSize = true;
            this.labelPlayer3.Location = new System.Drawing.Point(6, 16);
            this.labelPlayer3.Name = "labelPlayer3";
            this.labelPlayer3.Size = new System.Drawing.Size(39, 13);
            this.labelPlayer3.TabIndex = 0;
            this.labelPlayer3.Text = "Player:";
            // 
            // groupBoxPlayer4
            // 
            this.groupBoxPlayer4.Controls.Add(this.textBoxPlayer4LP);
            this.groupBoxPlayer4.Controls.Add(this.textBoxPlayer4Deck);
            this.groupBoxPlayer4.Controls.Add(this.textBoxPlayer4);
            this.groupBoxPlayer4.Controls.Add(this.buttonPlayer4);
            this.groupBoxPlayer4.Controls.Add(this.labelPlayer4LP);
            this.groupBoxPlayer4.Controls.Add(this.labelPlayer4Deck);
            this.groupBoxPlayer4.Controls.Add(this.labelPlayer4);
            this.groupBoxPlayer4.Location = new System.Drawing.Point(286, 12);
            this.groupBoxPlayer4.Name = "groupBoxPlayer4";
            this.groupBoxPlayer4.Size = new System.Drawing.Size(268, 110);
            this.groupBoxPlayer4.TabIndex = 11;
            this.groupBoxPlayer4.TabStop = false;
            this.groupBoxPlayer4.Text = "Player 4";
            // 
            // textBoxPlayer4LP
            // 
            this.textBoxPlayer4LP.Enabled = false;
            this.textBoxPlayer4LP.Location = new System.Drawing.Point(56, 69);
            this.textBoxPlayer4LP.Name = "textBoxPlayer4LP";
            this.textBoxPlayer4LP.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer4LP.TabIndex = 9;
            this.textBoxPlayer4LP.Text = "8000";
            this.textBoxPlayer4LP.TextChanged += new System.EventHandler(this.textBoxPlayer4LP_TextChanged);
            // 
            // textBoxPlayer4Deck
            // 
            this.textBoxPlayer4Deck.Location = new System.Drawing.Point(56, 43);
            this.textBoxPlayer4Deck.Name = "textBoxPlayer4Deck";
            this.textBoxPlayer4Deck.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer4Deck.TabIndex = 8;
            this.textBoxPlayer4Deck.TextChanged += new System.EventHandler(this.textBoxPlayer4Deck_TextChanged);
            // 
            // textBoxPlayer4
            // 
            this.textBoxPlayer4.Location = new System.Drawing.Point(56, 16);
            this.textBoxPlayer4.Name = "textBoxPlayer4";
            this.textBoxPlayer4.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer4.TabIndex = 7;
            this.textBoxPlayer4.TextChanged += new System.EventHandler(this.textBoxPlayer4_TextChanged);
            // 
            // buttonPlayer4
            // 
            this.buttonPlayer4.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonPlayer4.Location = new System.Drawing.Point(162, 29);
            this.buttonPlayer4.Name = "buttonPlayer4";
            this.buttonPlayer4.Size = new System.Drawing.Size(97, 47);
            this.buttonPlayer4.TabIndex = 6;
            this.buttonPlayer4.Text = "Apply";
            this.buttonPlayer4.UseVisualStyleBackColor = false;
            this.buttonPlayer4.Click += new System.EventHandler(this.buttonPlayer4_Click);
            // 
            // labelPlayer4LP
            // 
            this.labelPlayer4LP.AutoSize = true;
            this.labelPlayer4LP.Location = new System.Drawing.Point(6, 69);
            this.labelPlayer4LP.Name = "labelPlayer4LP";
            this.labelPlayer4LP.Size = new System.Drawing.Size(23, 13);
            this.labelPlayer4LP.TabIndex = 2;
            this.labelPlayer4LP.Text = "LP:";
            // 
            // labelPlayer4Deck
            // 
            this.labelPlayer4Deck.AutoSize = true;
            this.labelPlayer4Deck.Location = new System.Drawing.Point(6, 43);
            this.labelPlayer4Deck.Name = "labelPlayer4Deck";
            this.labelPlayer4Deck.Size = new System.Drawing.Size(36, 13);
            this.labelPlayer4Deck.TabIndex = 1;
            this.labelPlayer4Deck.Text = "Deck:";
            // 
            // labelPlayer4
            // 
            this.labelPlayer4.AutoSize = true;
            this.labelPlayer4.Location = new System.Drawing.Point(6, 16);
            this.labelPlayer4.Name = "labelPlayer4";
            this.labelPlayer4.Size = new System.Drawing.Size(39, 13);
            this.labelPlayer4.TabIndex = 0;
            this.labelPlayer4.Text = "Player:";
            // 
            // groupBoxPlayer5
            // 
            this.groupBoxPlayer5.Controls.Add(this.textBoxPlayer5LP);
            this.groupBoxPlayer5.Controls.Add(this.textBoxPlayer5Deck);
            this.groupBoxPlayer5.Controls.Add(this.textBoxPlayer5);
            this.groupBoxPlayer5.Controls.Add(this.buttonPlayer5);
            this.groupBoxPlayer5.Controls.Add(this.labelPlayer5LP);
            this.groupBoxPlayer5.Controls.Add(this.labelPlayer5Deck);
            this.groupBoxPlayer5.Controls.Add(this.labelPlayer5);
            this.groupBoxPlayer5.Location = new System.Drawing.Point(286, 128);
            this.groupBoxPlayer5.Name = "groupBoxPlayer5";
            this.groupBoxPlayer5.Size = new System.Drawing.Size(268, 110);
            this.groupBoxPlayer5.TabIndex = 10;
            this.groupBoxPlayer5.TabStop = false;
            this.groupBoxPlayer5.Text = "Player 5";
            // 
            // textBoxPlayer5LP
            // 
            this.textBoxPlayer5LP.Enabled = false;
            this.textBoxPlayer5LP.Location = new System.Drawing.Point(56, 69);
            this.textBoxPlayer5LP.Name = "textBoxPlayer5LP";
            this.textBoxPlayer5LP.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer5LP.TabIndex = 9;
            this.textBoxPlayer5LP.Text = "8000";
            this.textBoxPlayer5LP.TextChanged += new System.EventHandler(this.textBoxPlayer5LP_TextChanged);
            // 
            // textBoxPlayer5Deck
            // 
            this.textBoxPlayer5Deck.Location = new System.Drawing.Point(56, 43);
            this.textBoxPlayer5Deck.Name = "textBoxPlayer5Deck";
            this.textBoxPlayer5Deck.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer5Deck.TabIndex = 8;
            this.textBoxPlayer5Deck.TextChanged += new System.EventHandler(this.textBoxPlayer5Deck_TextChanged);
            // 
            // textBoxPlayer5
            // 
            this.textBoxPlayer5.Location = new System.Drawing.Point(56, 16);
            this.textBoxPlayer5.Name = "textBoxPlayer5";
            this.textBoxPlayer5.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer5.TabIndex = 7;
            this.textBoxPlayer5.TextChanged += new System.EventHandler(this.textBoxPlayer5_TextChanged);
            // 
            // buttonPlayer5
            // 
            this.buttonPlayer5.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonPlayer5.Location = new System.Drawing.Point(162, 29);
            this.buttonPlayer5.Name = "buttonPlayer5";
            this.buttonPlayer5.Size = new System.Drawing.Size(97, 47);
            this.buttonPlayer5.TabIndex = 6;
            this.buttonPlayer5.Text = "Apply";
            this.buttonPlayer5.UseVisualStyleBackColor = false;
            this.buttonPlayer5.Click += new System.EventHandler(this.buttonPlayer5_Click);
            // 
            // labelPlayer5LP
            // 
            this.labelPlayer5LP.AutoSize = true;
            this.labelPlayer5LP.Location = new System.Drawing.Point(6, 69);
            this.labelPlayer5LP.Name = "labelPlayer5LP";
            this.labelPlayer5LP.Size = new System.Drawing.Size(23, 13);
            this.labelPlayer5LP.TabIndex = 2;
            this.labelPlayer5LP.Text = "LP:";
            // 
            // labelPlayer5Deck
            // 
            this.labelPlayer5Deck.AutoSize = true;
            this.labelPlayer5Deck.Location = new System.Drawing.Point(6, 43);
            this.labelPlayer5Deck.Name = "labelPlayer5Deck";
            this.labelPlayer5Deck.Size = new System.Drawing.Size(36, 13);
            this.labelPlayer5Deck.TabIndex = 1;
            this.labelPlayer5Deck.Text = "Deck:";
            // 
            // labelPlayer5
            // 
            this.labelPlayer5.AutoSize = true;
            this.labelPlayer5.Location = new System.Drawing.Point(6, 16);
            this.labelPlayer5.Name = "labelPlayer5";
            this.labelPlayer5.Size = new System.Drawing.Size(39, 13);
            this.labelPlayer5.TabIndex = 0;
            this.labelPlayer5.Text = "Player:";
            // 
            // groupBoxPlayer6
            // 
            this.groupBoxPlayer6.Controls.Add(this.textBoxPlayer6LP);
            this.groupBoxPlayer6.Controls.Add(this.textBoxPlayer6Deck);
            this.groupBoxPlayer6.Controls.Add(this.textBoxPlayer6);
            this.groupBoxPlayer6.Controls.Add(this.buttonPlayer6);
            this.groupBoxPlayer6.Controls.Add(this.labelPlayer6LP);
            this.groupBoxPlayer6.Controls.Add(this.labelPlayer6Deck);
            this.groupBoxPlayer6.Controls.Add(this.labelPlayer6);
            this.groupBoxPlayer6.Location = new System.Drawing.Point(286, 244);
            this.groupBoxPlayer6.Name = "groupBoxPlayer6";
            this.groupBoxPlayer6.Size = new System.Drawing.Size(268, 110);
            this.groupBoxPlayer6.TabIndex = 12;
            this.groupBoxPlayer6.TabStop = false;
            this.groupBoxPlayer6.Text = "Player 6";
            // 
            // textBoxPlayer6LP
            // 
            this.textBoxPlayer6LP.Enabled = false;
            this.textBoxPlayer6LP.Location = new System.Drawing.Point(56, 69);
            this.textBoxPlayer6LP.Name = "textBoxPlayer6LP";
            this.textBoxPlayer6LP.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer6LP.TabIndex = 9;
            this.textBoxPlayer6LP.Text = "8000";
            this.textBoxPlayer6LP.TextChanged += new System.EventHandler(this.textBoxPlayer6LP_TextChanged);
            // 
            // textBoxPlayer6Deck
            // 
            this.textBoxPlayer6Deck.Location = new System.Drawing.Point(56, 43);
            this.textBoxPlayer6Deck.Name = "textBoxPlayer6Deck";
            this.textBoxPlayer6Deck.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer6Deck.TabIndex = 8;
            this.textBoxPlayer6Deck.TextChanged += new System.EventHandler(this.textBoxPlayer6Deck_TextChanged);
            // 
            // textBoxPlayer6
            // 
            this.textBoxPlayer6.Location = new System.Drawing.Point(56, 16);
            this.textBoxPlayer6.Name = "textBoxPlayer6";
            this.textBoxPlayer6.Size = new System.Drawing.Size(100, 20);
            this.textBoxPlayer6.TabIndex = 7;
            this.textBoxPlayer6.TextChanged += new System.EventHandler(this.textBoxPlayer6_TextChanged);
            // 
            // buttonPlayer6
            // 
            this.buttonPlayer6.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonPlayer6.Location = new System.Drawing.Point(162, 29);
            this.buttonPlayer6.Name = "buttonPlayer6";
            this.buttonPlayer6.Size = new System.Drawing.Size(97, 47);
            this.buttonPlayer6.TabIndex = 6;
            this.buttonPlayer6.Text = "Apply";
            this.buttonPlayer6.UseVisualStyleBackColor = false;
            this.buttonPlayer6.Click += new System.EventHandler(this.buttonPlayer6_Click);
            // 
            // labelPlayer6LP
            // 
            this.labelPlayer6LP.AutoSize = true;
            this.labelPlayer6LP.Location = new System.Drawing.Point(6, 69);
            this.labelPlayer6LP.Name = "labelPlayer6LP";
            this.labelPlayer6LP.Size = new System.Drawing.Size(23, 13);
            this.labelPlayer6LP.TabIndex = 2;
            this.labelPlayer6LP.Text = "LP:";
            // 
            // labelPlayer6Deck
            // 
            this.labelPlayer6Deck.AutoSize = true;
            this.labelPlayer6Deck.Location = new System.Drawing.Point(6, 43);
            this.labelPlayer6Deck.Name = "labelPlayer6Deck";
            this.labelPlayer6Deck.Size = new System.Drawing.Size(36, 13);
            this.labelPlayer6Deck.TabIndex = 1;
            this.labelPlayer6Deck.Text = "Deck:";
            // 
            // labelPlayer6
            // 
            this.labelPlayer6.AutoSize = true;
            this.labelPlayer6.Location = new System.Drawing.Point(6, 16);
            this.labelPlayer6.Name = "labelPlayer6";
            this.labelPlayer6.Size = new System.Drawing.Size(39, 13);
            this.labelPlayer6.TabIndex = 0;
            this.labelPlayer6.Text = "Player:";
            // 
            // buttonCoin
            // 
            this.buttonCoin.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonCoin.Location = new System.Drawing.Point(560, 30);
            this.buttonCoin.Name = "buttonCoin";
            this.buttonCoin.Size = new System.Drawing.Size(75, 23);
            this.buttonCoin.TabIndex = 13;
            this.buttonCoin.Text = "Coin Flip";
            this.buttonCoin.UseVisualStyleBackColor = false;
            this.buttonCoin.Click += new System.EventHandler(this.buttonCoin_Click);
            // 
            // buttonD6
            // 
            this.buttonD6.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonD6.Location = new System.Drawing.Point(644, 30);
            this.buttonD6.Name = "buttonD6";
            this.buttonD6.Size = new System.Drawing.Size(75, 23);
            this.buttonD6.TabIndex = 14;
            this.buttonD6.Text = "Roll 1d6";
            this.buttonD6.UseVisualStyleBackColor = false;
            this.buttonD6.Click += new System.EventHandler(this.buttonD6_Click);
            // 
            // buttonD20
            // 
            this.buttonD20.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonD20.Location = new System.Drawing.Point(560, 59);
            this.buttonD20.Name = "buttonD20";
            this.buttonD20.Size = new System.Drawing.Size(75, 23);
            this.buttonD20.TabIndex = 15;
            this.buttonD20.Text = "Roll 1d20";
            this.buttonD20.UseVisualStyleBackColor = false;
            this.buttonD20.Click += new System.EventHandler(this.buttonD20_Click);
            // 
            // button50
            // 
            this.button50.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button50.Location = new System.Drawing.Point(560, 99);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(75, 23);
            this.button50.TabIndex = 16;
            this.button50.Text = "50";
            this.button50.UseVisualStyleBackColor = false;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // buttonMinus50
            // 
            this.buttonMinus50.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonMinus50.Location = new System.Drawing.Point(641, 99);
            this.buttonMinus50.Name = "buttonMinus50";
            this.buttonMinus50.Size = new System.Drawing.Size(75, 23);
            this.buttonMinus50.TabIndex = 17;
            this.buttonMinus50.Text = "-50";
            this.buttonMinus50.UseVisualStyleBackColor = false;
            this.buttonMinus50.Click += new System.EventHandler(this.buttonMinus50_Click);
            // 
            // button100
            // 
            this.button100.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button100.Location = new System.Drawing.Point(560, 128);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(75, 23);
            this.button100.TabIndex = 18;
            this.button100.Text = "100";
            this.button100.UseVisualStyleBackColor = false;
            this.button100.Click += new System.EventHandler(this.button100_Click);
            // 
            // buttonMinus100
            // 
            this.buttonMinus100.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonMinus100.Location = new System.Drawing.Point(641, 128);
            this.buttonMinus100.Name = "buttonMinus100";
            this.buttonMinus100.Size = new System.Drawing.Size(75, 23);
            this.buttonMinus100.TabIndex = 19;
            this.buttonMinus100.Text = "-100";
            this.buttonMinus100.UseVisualStyleBackColor = false;
            this.buttonMinus100.Click += new System.EventHandler(this.buttonMinus100_Click);
            // 
            // button500
            // 
            this.button500.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button500.Location = new System.Drawing.Point(560, 157);
            this.button500.Name = "button500";
            this.button500.Size = new System.Drawing.Size(75, 23);
            this.button500.TabIndex = 20;
            this.button500.Text = "500";
            this.button500.UseVisualStyleBackColor = false;
            this.button500.Click += new System.EventHandler(this.button500_Click);
            // 
            // buttonMinus500
            // 
            this.buttonMinus500.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonMinus500.Location = new System.Drawing.Point(641, 157);
            this.buttonMinus500.Name = "buttonMinus500";
            this.buttonMinus500.Size = new System.Drawing.Size(75, 23);
            this.buttonMinus500.TabIndex = 21;
            this.buttonMinus500.Text = "-500";
            this.buttonMinus500.UseVisualStyleBackColor = false;
            this.buttonMinus500.Click += new System.EventHandler(this.buttonMinus500_Click);
            // 
            // button1000
            // 
            this.button1000.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button1000.Location = new System.Drawing.Point(560, 186);
            this.button1000.Name = "button1000";
            this.button1000.Size = new System.Drawing.Size(75, 23);
            this.button1000.TabIndex = 22;
            this.button1000.Text = "1000";
            this.button1000.UseVisualStyleBackColor = false;
            this.button1000.Click += new System.EventHandler(this.button1000_Click);
            // 
            // buttonMinus1000
            // 
            this.buttonMinus1000.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonMinus1000.Location = new System.Drawing.Point(641, 186);
            this.buttonMinus1000.Name = "buttonMinus1000";
            this.buttonMinus1000.Size = new System.Drawing.Size(75, 23);
            this.buttonMinus1000.TabIndex = 23;
            this.buttonMinus1000.Text = "-1000";
            this.buttonMinus1000.UseVisualStyleBackColor = false;
            this.buttonMinus1000.Click += new System.EventHandler(this.buttonMinus1000_Click);
            // 
            // labelCustomValue
            // 
            this.labelCustomValue.AutoSize = true;
            this.labelCustomValue.Location = new System.Drawing.Point(557, 212);
            this.labelCustomValue.Name = "labelCustomValue";
            this.labelCustomValue.Size = new System.Drawing.Size(103, 13);
            this.labelCustomValue.TabIndex = 24;
            this.labelCustomValue.Text = "Enter Custom Value:";
            // 
            // textBoxCustomValue
            // 
            this.textBoxCustomValue.Location = new System.Drawing.Point(560, 230);
            this.textBoxCustomValue.Name = "textBoxCustomValue";
            this.textBoxCustomValue.Size = new System.Drawing.Size(192, 20);
            this.textBoxCustomValue.TabIndex = 25;
            this.textBoxCustomValue.TextChanged += new System.EventHandler(this.textBoxCustomValue_TextChanged);
            // 
            // labelDice
            // 
            this.labelDice.AutoSize = true;
            this.labelDice.Location = new System.Drawing.Point(560, 12);
            this.labelDice.Name = "labelDice";
            this.labelDice.Size = new System.Drawing.Size(32, 13);
            this.labelDice.TabIndex = 26;
            this.labelDice.Text = "Dice:";
            // 
            // labelQuickValues
            // 
            this.labelQuickValues.AutoSize = true;
            this.labelQuickValues.Location = new System.Drawing.Point(560, 81);
            this.labelQuickValues.Name = "labelQuickValues";
            this.labelQuickValues.Size = new System.Drawing.Size(73, 13);
            this.labelQuickValues.TabIndex = 27;
            this.labelQuickValues.Text = "Quick Values:";
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonExit.Location = new System.Drawing.Point(677, 415);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(75, 23);
            this.buttonExit.TabIndex = 28;
            this.buttonExit.Text = "EXIT";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonReset
            // 
            this.buttonReset.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonReset.Location = new System.Drawing.Point(596, 415);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(75, 23);
            this.buttonReset.TabIndex = 29;
            this.buttonReset.Text = "RESET";
            this.buttonReset.UseVisualStyleBackColor = false;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // buttonStats
            // 
            this.buttonStats.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonStats.Location = new System.Drawing.Point(515, 415);
            this.buttonStats.Name = "buttonStats";
            this.buttonStats.Size = new System.Drawing.Size(75, 23);
            this.buttonStats.TabIndex = 30;
            this.buttonStats.Text = "STATS";
            this.buttonStats.UseVisualStyleBackColor = false;
            this.buttonStats.Click += new System.EventHandler(this.buttonStats_Click);
            // 
            // buttonVictory
            // 
            this.buttonVictory.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonVictory.Location = new System.Drawing.Point(434, 415);
            this.buttonVictory.Name = "buttonVictory";
            this.buttonVictory.Size = new System.Drawing.Size(75, 23);
            this.buttonVictory.TabIndex = 31;
            this.buttonVictory.Text = "VICTORY";
            this.buttonVictory.UseVisualStyleBackColor = false;
            this.buttonVictory.Click += new System.EventHandler(this.buttonVictory_Click);
            // 
            // labelPreparedAction
            // 
            this.labelPreparedAction.AutoSize = true;
            this.labelPreparedAction.Location = new System.Drawing.Point(12, 357);
            this.labelPreparedAction.Name = "labelPreparedAction";
            this.labelPreparedAction.Size = new System.Drawing.Size(86, 13);
            this.labelPreparedAction.TabIndex = 32;
            this.labelPreparedAction.Text = "Prepared Action:";
            // 
            // labelLastAction
            // 
            this.labelLastAction.AutoSize = true;
            this.labelLastAction.Location = new System.Drawing.Point(12, 381);
            this.labelLastAction.Name = "labelLastAction";
            this.labelLastAction.Size = new System.Drawing.Size(63, 13);
            this.labelLastAction.TabIndex = 33;
            this.labelLastAction.Text = "Last Action:";
            // 
            // listBoxActionHistory
            // 
            this.listBoxActionHistory.FormattingEnabled = true;
            this.listBoxActionHistory.Location = new System.Drawing.Point(563, 260);
            this.listBoxActionHistory.Name = "listBoxActionHistory";
            this.listBoxActionHistory.Size = new System.Drawing.Size(189, 147);
            this.listBoxActionHistory.TabIndex = 34;
            this.listBoxActionHistory.SelectedIndexChanged += new System.EventHandler(this.listBoxActionHistory_SelectedIndexChanged);
            // 
            // textBoxPreparedAction
            // 
            this.textBoxPreparedAction.Enabled = false;
            this.textBoxPreparedAction.Location = new System.Drawing.Point(115, 357);
            this.textBoxPreparedAction.Name = "textBoxPreparedAction";
            this.textBoxPreparedAction.Size = new System.Drawing.Size(430, 20);
            this.textBoxPreparedAction.TabIndex = 35;
            this.textBoxPreparedAction.TextChanged += new System.EventHandler(this.textBoxPreparedAction_TextChanged);
            // 
            // textBoxLastAction
            // 
            this.textBoxLastAction.Enabled = false;
            this.textBoxLastAction.Location = new System.Drawing.Point(115, 381);
            this.textBoxLastAction.Name = "textBoxLastAction";
            this.textBoxLastAction.Size = new System.Drawing.Size(430, 20);
            this.textBoxLastAction.TabIndex = 36;
            this.textBoxLastAction.TextChanged += new System.EventHandler(this.textBoxLastAction_TextChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button1.Location = new System.Drawing.Point(353, 415);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 37;
            this.button1.Text = "UPDATE";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(764, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBoxLastAction);
            this.Controls.Add(this.textBoxPreparedAction);
            this.Controls.Add(this.listBoxActionHistory);
            this.Controls.Add(this.labelLastAction);
            this.Controls.Add(this.labelPreparedAction);
            this.Controls.Add(this.buttonVictory);
            this.Controls.Add(this.buttonStats);
            this.Controls.Add(this.buttonReset);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.labelQuickValues);
            this.Controls.Add(this.labelDice);
            this.Controls.Add(this.textBoxCustomValue);
            this.Controls.Add(this.labelCustomValue);
            this.Controls.Add(this.buttonMinus1000);
            this.Controls.Add(this.button1000);
            this.Controls.Add(this.buttonMinus500);
            this.Controls.Add(this.button500);
            this.Controls.Add(this.buttonMinus100);
            this.Controls.Add(this.button100);
            this.Controls.Add(this.buttonMinus50);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.buttonD20);
            this.Controls.Add(this.buttonD6);
            this.Controls.Add(this.buttonCoin);
            this.Controls.Add(this.groupBoxPlayer6);
            this.Controls.Add(this.groupBoxPlayer5);
            this.Controls.Add(this.groupBoxPlayer4);
            this.Controls.Add(this.groupBoxPlayer3);
            this.Controls.Add(this.groupBoxPlayer2);
            this.Controls.Add(this.groupBoxPlayer1);
            this.Name = "FormMain";
            this.Text = "Life Point Counter";
            this.groupBoxPlayer1.ResumeLayout(false);
            this.groupBoxPlayer1.PerformLayout();
            this.groupBoxPlayer2.ResumeLayout(false);
            this.groupBoxPlayer2.PerformLayout();
            this.groupBoxPlayer3.ResumeLayout(false);
            this.groupBoxPlayer3.PerformLayout();
            this.groupBoxPlayer4.ResumeLayout(false);
            this.groupBoxPlayer4.PerformLayout();
            this.groupBoxPlayer5.ResumeLayout(false);
            this.groupBoxPlayer5.PerformLayout();
            this.groupBoxPlayer6.ResumeLayout(false);
            this.groupBoxPlayer6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxPlayer1;
        private System.Windows.Forms.Label labelPlayer1LP;
        private System.Windows.Forms.Label labelPlayer1Deck;
        private System.Windows.Forms.Label labelPlayer1;
        private System.Windows.Forms.TextBox textBoxPlayer1Deck;
        private System.Windows.Forms.TextBox textBoxPlayer1;
        private System.Windows.Forms.Button buttonPlayer1;
        private System.Windows.Forms.TextBox textBoxPlayer1LP;
        private System.Windows.Forms.GroupBox groupBoxPlayer2;
        private System.Windows.Forms.TextBox textBoxPlayer2LP;
        private System.Windows.Forms.TextBox textBoxPlayer2Deck;
        private System.Windows.Forms.TextBox textBoxPlayer2;
        private System.Windows.Forms.Button buttonPlayer2;
        private System.Windows.Forms.Label labelPlayer2LP;
        private System.Windows.Forms.Label labelPlayer2Deck;
        private System.Windows.Forms.Label labelPlayer2;
        private System.Windows.Forms.GroupBox groupBoxPlayer3;
        private System.Windows.Forms.TextBox textBoxPlayer3LP;
        private System.Windows.Forms.TextBox textBoxPlayer3Deck;
        private System.Windows.Forms.TextBox textBoxPlayer3;
        private System.Windows.Forms.Button buttonPlayer3;
        private System.Windows.Forms.Label labelPlayer3LP;
        private System.Windows.Forms.Label labelPlayer3Deck;
        private System.Windows.Forms.Label labelPlayer3;
        private System.Windows.Forms.GroupBox groupBoxPlayer4;
        private System.Windows.Forms.TextBox textBoxPlayer4LP;
        private System.Windows.Forms.TextBox textBoxPlayer4Deck;
        private System.Windows.Forms.TextBox textBoxPlayer4;
        private System.Windows.Forms.Button buttonPlayer4;
        private System.Windows.Forms.Label labelPlayer4LP;
        private System.Windows.Forms.Label labelPlayer4Deck;
        private System.Windows.Forms.Label labelPlayer4;
        private System.Windows.Forms.GroupBox groupBoxPlayer5;
        private System.Windows.Forms.TextBox textBoxPlayer5LP;
        private System.Windows.Forms.TextBox textBoxPlayer5Deck;
        private System.Windows.Forms.TextBox textBoxPlayer5;
        private System.Windows.Forms.Button buttonPlayer5;
        private System.Windows.Forms.Label labelPlayer5LP;
        private System.Windows.Forms.Label labelPlayer5Deck;
        private System.Windows.Forms.Label labelPlayer5;
        private System.Windows.Forms.GroupBox groupBoxPlayer6;
        private System.Windows.Forms.TextBox textBoxPlayer6LP;
        private System.Windows.Forms.TextBox textBoxPlayer6Deck;
        private System.Windows.Forms.TextBox textBoxPlayer6;
        private System.Windows.Forms.Button buttonPlayer6;
        private System.Windows.Forms.Label labelPlayer6LP;
        private System.Windows.Forms.Label labelPlayer6Deck;
        private System.Windows.Forms.Label labelPlayer6;
        private System.Windows.Forms.Button buttonCoin;
        private System.Windows.Forms.Button buttonD6;
        private System.Windows.Forms.Button buttonD20;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button buttonMinus50;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Button buttonMinus100;
        private System.Windows.Forms.Button button500;
        private System.Windows.Forms.Button buttonMinus500;
        private System.Windows.Forms.Button button1000;
        private System.Windows.Forms.Button buttonMinus1000;
        private System.Windows.Forms.Label labelCustomValue;
        private System.Windows.Forms.TextBox textBoxCustomValue;
        private System.Windows.Forms.Label labelDice;
        private System.Windows.Forms.Label labelQuickValues;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.Button buttonStats;
        private System.Windows.Forms.Button buttonVictory;
        private System.Windows.Forms.Label labelPreparedAction;
        private System.Windows.Forms.Label labelLastAction;
        private System.Windows.Forms.ListBox listBoxActionHistory;
        private System.Windows.Forms.TextBox textBoxPreparedAction;
        private System.Windows.Forms.TextBox textBoxLastAction;
        private System.Windows.Forms.Button button1;
    }
}