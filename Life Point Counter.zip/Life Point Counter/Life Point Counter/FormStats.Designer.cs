﻿namespace Life_Point_Counter
{
    partial class FormStats
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxStats = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // listBoxStats
            // 
            this.listBoxStats.FormattingEnabled = true;
            this.listBoxStats.Location = new System.Drawing.Point(12, 12);
            this.listBoxStats.Name = "listBoxStats";
            this.listBoxStats.Size = new System.Drawing.Size(835, 511);
            this.listBoxStats.TabIndex = 0;
            this.listBoxStats.SelectedIndexChanged += new System.EventHandler(this.listBoxStats_SelectedIndexChanged);
            // 
            // FormStats
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(859, 540);
            this.Controls.Add(this.listBoxStats);
            this.Name = "FormStats";
            this.Text = "FormStats";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxStats;
    }
}